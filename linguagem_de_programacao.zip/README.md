# BOLT

Este código é um aplicativo Flutter que inclui uma tela inicial (SplashScreen), uma tela de login (LoginPage), uma tela de inscrição (SignupPage), uma tela de boas-vindas (WelcomePage) e uma tela para adicionar um eletrodoméstico 

----